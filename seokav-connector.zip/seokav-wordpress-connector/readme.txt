=== Seokav Connector ===
Contributors: seokav
Tags: seo, woocommerce, api, connector
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

اتصال امن سئوکاو به وردپرس و ووکامرس.

== Installation ==

1. فایل ZIP افزونه را از بخش افزونه‌ها بارگذاری و فعال کنید.
2. در وردپرس از پروفایل کاربر یک Application Password مخصوص «Seokav» بسازید.
3. نام کاربری و Application Password را در داشبورد سئوکاو وارد کنید.

رمز اصلی وردپرس هرگز لازم نیست. دسترسی با حذف Application Password از پروفایل وردپرس فوراً قطع می‌شود.
