<?php
/**
 * Plugin Name: Seokav Connector
 * Plugin URI: https://seokav.app
 * Description: اتصال امن و محدود سئوکاو به وردپرس و ووکامرس برای مدیریت دسته‌ها، محصولات و متادیتای سئو.
 * Version: 1.0.0
 * Author: Seokav
 * Requires at least: 6.4
 * Requires PHP: 8.0
 * Text Domain: seokav-connector
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Seokav_Connector {
    const VERSION = '1.0.0';
    const NAMESPACE = 'seokav/v1';

    public static function boot() {
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    public static function register_routes() {
        register_rest_route(self::NAMESPACE, '/health', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'health'],
            'permission_callback' => [__CLASS__, 'can_manage_seokav'],
        ]);

        register_rest_route(self::NAMESPACE, '/categories', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'categories'],
            'permission_callback' => [__CLASS__, 'can_manage_seokav'],
        ]);

        register_rest_route(self::NAMESPACE, '/categories/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [__CLASS__, 'category'],
                'permission_callback' => [__CLASS__, 'can_manage_seokav'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [__CLASS__, 'update_category'],
                'permission_callback' => [__CLASS__, 'can_manage_seokav'],
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/products', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'products'],
            'permission_callback' => [__CLASS__, 'can_manage_seokav'],
        ]);

        register_rest_route(self::NAMESPACE, '/products/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [__CLASS__, 'product'],
                'permission_callback' => [__CLASS__, 'can_manage_seokav'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [__CLASS__, 'update_product'],
                'permission_callback' => [__CLASS__, 'can_manage_seokav'],
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/content/(?P<type>[a-zA-Z0-9_-]+)/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [__CLASS__, 'content'],
                'permission_callback' => [__CLASS__, 'can_edit_content'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [__CLASS__, 'update_content'],
                'permission_callback' => [__CLASS__, 'can_edit_content'],
            ],
        ]);
    }

    public static function can_manage_seokav() {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    public static function can_edit_content(WP_REST_Request $request) {
        return current_user_can('edit_post', absint($request['id']));
    }

    public static function health() {
        return rest_ensure_response([
            'ok' => true,
            'version' => self::VERSION,
            'wordpress_version' => get_bloginfo('version'),
            'woocommerce' => class_exists('WooCommerce') ? WC_VERSION : null,
            'site_url' => home_url('/'),
            'capabilities' => [
                'categories.read',
                'categories.write',
                'content.read',
                'content.write',
                class_exists('WooCommerce') ? 'products.read' : null,
                class_exists('WooCommerce') ? 'products.write' : null,
            ],
        ]);
    }

    private static function require_woocommerce() {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_product')) {
            return new WP_Error('seokav_woocommerce_missing', 'ووکامرس فعال نیست.', ['status' => 409]);
        }
        return true;
    }

    private static function seo_meta($object_id, $taxonomy = '') {
        $reader = $taxonomy ? 'get_term_meta' : 'get_post_meta';
        $title = call_user_func($reader, $object_id, '_yoast_wpseo_title', true);
        $description = call_user_func($reader, $object_id, '_yoast_wpseo_metadesc', true);
        if ($title === '') {
            $title = call_user_func($reader, $object_id, 'rank_math_title', true);
        }
        if ($description === '') {
            $description = call_user_func($reader, $object_id, 'rank_math_description', true);
        }
        return ['seo_title' => (string) $title, 'seo_description' => (string) $description];
    }

    private static function update_seo_meta($object_id, WP_REST_Request $request, $taxonomy = '') {
        $writer = $taxonomy ? 'update_term_meta' : 'update_post_meta';
        if ($request->has_param('seo_title')) {
            $value = sanitize_text_field((string) $request->get_param('seo_title'));
            call_user_func($writer, $object_id, '_yoast_wpseo_title', $value);
            call_user_func($writer, $object_id, 'rank_math_title', $value);
        }
        if ($request->has_param('seo_description')) {
            $value = sanitize_textarea_field((string) $request->get_param('seo_description'));
            call_user_func($writer, $object_id, '_yoast_wpseo_metadesc', $value);
            call_user_func($writer, $object_id, 'rank_math_description', $value);
        }
    }

    private static function category_payload(WP_Term $term) {
        return array_merge([
            'id' => $term->term_id,
            'name' => $term->name,
            'slug' => $term->slug,
            'description' => $term->description,
            'parent' => $term->parent,
            'count' => $term->count,
            'permalink' => get_term_link($term),
        ], self::seo_meta($term->term_id, 'product_cat'));
    }

    public static function categories(WP_REST_Request $request) {
        $taxonomy = taxonomy_exists('product_cat') ? 'product_cat' : 'category';
        $terms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'number' => min(200, max(1, absint($request->get_param('per_page') ?: 100))),
            'offset' => max(0, (absint($request->get_param('page') ?: 1) - 1) * absint($request->get_param('per_page') ?: 100)),
        ]);
        if (is_wp_error($terms)) {
            return $terms;
        }
        return rest_ensure_response(['categories' => array_map([__CLASS__, 'category_payload'], $terms)]);
    }

    public static function category(WP_REST_Request $request) {
        $term = get_term(absint($request['id']), 'product_cat');
        if (!$term || is_wp_error($term)) {
            return new WP_Error('seokav_category_missing', 'دسته پیدا نشد.', ['status' => 404]);
        }
        return rest_ensure_response(self::category_payload($term));
    }

    public static function update_category(WP_REST_Request $request) {
        $id = absint($request['id']);
        $term = get_term($id, 'product_cat');
        if (!$term || is_wp_error($term)) {
            return new WP_Error('seokav_category_missing', 'دسته پیدا نشد.', ['status' => 404]);
        }
        $args = [];
        if ($request->has_param('name')) {
            $args['name'] = sanitize_text_field((string) $request->get_param('name'));
        }
        if ($request->has_param('slug')) {
            $args['slug'] = sanitize_title((string) $request->get_param('slug'));
        }
        if ($request->has_param('description')) {
            $args['description'] = wp_kses_post((string) $request->get_param('description'));
        }
        if ($request->has_param('parent')) {
            $parent = absint($request->get_param('parent'));
            if ($parent === $id) {
                return new WP_Error('seokav_invalid_parent', 'یک دسته نمی‌تواند والد خودش باشد.', ['status' => 400]);
            }
            $args['parent'] = $parent;
        }
        if ($args) {
            $result = wp_update_term($id, 'product_cat', $args);
            if (is_wp_error($result)) {
                return $result;
            }
        }
        self::update_seo_meta($id, $request, 'product_cat');
        clean_term_cache($id, 'product_cat');
        return self::category($request);
    }

    private static function product_payload(WC_Product $product) {
        $categories = array_map('absint', $product->get_category_ids());
        return array_merge([
            'id' => $product->get_id(),
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'status' => $product->get_status(),
            'sku' => $product->get_sku(),
            'regular_price' => $product->get_regular_price(),
            'sale_price' => $product->get_sale_price(),
            'stock_status' => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'short_description' => $product->get_short_description(),
            'description' => $product->get_description(),
            'categories' => $categories,
            'permalink' => $product->get_permalink(),
            'modified_at' => $product->get_date_modified() ? $product->get_date_modified()->date(DATE_ATOM) : null,
        ], self::seo_meta($product->get_id()));
    }

    public static function products(WP_REST_Request $request) {
        $ready = self::require_woocommerce();
        if (is_wp_error($ready)) {
            return $ready;
        }
        $page = max(1, absint($request->get_param('page') ?: 1));
        $per_page = min(100, max(1, absint($request->get_param('per_page') ?: 50)));
        $query = [
            'limit' => $per_page,
            'page' => $page,
            'paginate' => true,
            'status' => array_keys(wc_get_product_statuses()),
            'orderby' => 'modified',
            'order' => 'DESC',
        ];
        $search = sanitize_text_field((string) $request->get_param('search'));
        if ($search !== '') {
            $query['s'] = $search;
        }
        $result = wc_get_products($query);
        return rest_ensure_response([
            'products' => array_map([__CLASS__, 'product_payload'], $result->products),
            'total' => $result->total,
            'max_pages' => $result->max_num_pages,
        ]);
    }

    public static function product(WP_REST_Request $request) {
        $ready = self::require_woocommerce();
        if (is_wp_error($ready)) {
            return $ready;
        }
        $product = wc_get_product(absint($request['id']));
        if (!$product) {
            return new WP_Error('seokav_product_missing', 'محصول پیدا نشد.', ['status' => 404]);
        }
        return rest_ensure_response(self::product_payload($product));
    }

    public static function update_product(WP_REST_Request $request) {
        $ready = self::require_woocommerce();
        if (is_wp_error($ready)) {
            return $ready;
        }
        $product = wc_get_product(absint($request['id']));
        if (!$product) {
            return new WP_Error('seokav_product_missing', 'محصول پیدا نشد.', ['status' => 404]);
        }

        $commercial_fields = ['regular_price', 'sale_price', 'stock_status', 'stock_quantity'];
        foreach ($commercial_fields as $field) {
            if ($request->has_param($field) && $request->get_param('confirm_commercial_changes') !== true) {
                return new WP_Error('seokav_confirmation_required', 'تغییر قیمت یا موجودی به تأیید صریح نیاز دارد.', ['status' => 400]);
            }
        }

        if ($request->has_param('name')) $product->set_name(sanitize_text_field((string) $request->get_param('name')));
        if ($request->has_param('slug')) $product->set_slug(sanitize_title((string) $request->get_param('slug')));
        if ($request->has_param('status')) $product->set_status(sanitize_key((string) $request->get_param('status')));
        if ($request->has_param('sku')) $product->set_sku(wc_clean((string) $request->get_param('sku')));
        if ($request->has_param('description')) $product->set_description(wp_kses_post((string) $request->get_param('description')));
        if ($request->has_param('short_description')) $product->set_short_description(wp_kses_post((string) $request->get_param('short_description')));
        if ($request->has_param('regular_price')) $product->set_regular_price(wc_format_decimal($request->get_param('regular_price')));
        if ($request->has_param('sale_price')) $product->set_sale_price(wc_format_decimal($request->get_param('sale_price')));
        if ($request->has_param('stock_status')) $product->set_stock_status(wc_clean((string) $request->get_param('stock_status')));
        if ($request->has_param('stock_quantity')) {
            $product->set_manage_stock(true);
            $product->set_stock_quantity(wc_stock_amount($request->get_param('stock_quantity')));
        }
        if ($request->has_param('categories')) {
            $product->set_category_ids(array_map('absint', (array) $request->get_param('categories')));
        }
        $product->save();
        self::update_seo_meta($product->get_id(), $request);
        return rest_ensure_response(self::product_payload(wc_get_product($product->get_id())));
    }

    private static function content_payload(WP_Post $post) {
        return array_merge([
            'id' => $post->ID,
            'type' => $post->post_type,
            'title' => get_the_title($post),
            'slug' => $post->post_name,
            'status' => $post->post_status,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'permalink' => get_permalink($post),
        ], self::seo_meta($post->ID));
    }

    public static function content(WP_REST_Request $request) {
        $post = get_post(absint($request['id']));
        if (!$post || $post->post_type !== sanitize_key($request['type'])) {
            return new WP_Error('seokav_content_missing', 'محتوا پیدا نشد.', ['status' => 404]);
        }
        return rest_ensure_response(self::content_payload($post));
    }

    public static function update_content(WP_REST_Request $request) {
        $post = get_post(absint($request['id']));
        if (!$post || $post->post_type !== sanitize_key($request['type'])) {
            return new WP_Error('seokav_content_missing', 'محتوا پیدا نشد.', ['status' => 404]);
        }
        $update = ['ID' => $post->ID];
        if ($request->has_param('title')) $update['post_title'] = sanitize_text_field((string) $request->get_param('title'));
        if ($request->has_param('slug')) $update['post_name'] = sanitize_title((string) $request->get_param('slug'));
        if ($request->has_param('status')) $update['post_status'] = sanitize_key((string) $request->get_param('status'));
        if ($request->has_param('content')) $update['post_content'] = wp_kses_post((string) $request->get_param('content'));
        if ($request->has_param('excerpt')) $update['post_excerpt'] = wp_kses_post((string) $request->get_param('excerpt'));
        if (count($update) > 1) {
            $result = wp_update_post($update, true);
            if (is_wp_error($result)) return $result;
        }
        self::update_seo_meta($post->ID, $request);
        return rest_ensure_response(self::content_payload(get_post($post->ID)));
    }
}

Seokav_Connector::boot();
